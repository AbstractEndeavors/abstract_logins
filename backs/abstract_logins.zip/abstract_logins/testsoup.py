from abstract_webtools import *
url = 'https://www.facebook.com/groups/648677616005071/permalink/1865861510953336/'
soup_mgr = soupManager(url)
soup = soup_mgr.soup
input(soup)
