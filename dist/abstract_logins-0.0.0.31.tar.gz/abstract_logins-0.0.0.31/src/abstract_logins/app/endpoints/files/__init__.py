from .routes import (
    secure_env_bp,
    secure_files_bp,
    secure_upload_bp,
    secure_remove_bp,
    secure_register_bp,
    secure_download_bp
    )
