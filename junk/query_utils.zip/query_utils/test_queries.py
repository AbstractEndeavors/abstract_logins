from py import *
from py.request_queries.requestManager import *
#input(get_query_utils_dir())
#input(get_user_ip_queries_path())
#data = safe_read_from_json(get_user_ip_queries_path())
#input(data)
req_mgr = extract_request_data()

ip_mgr = UserIPManager()
blacklist_mgr = BlacklistManager()
table_mgr = TableManager()
upload_mgr = UploadManager()
user_mgr = UserManager()
existing_users = user_mgr.get_existing_users()
blacklist_mgr.create_blacklist_table()
table_mgr.create_users_table()
