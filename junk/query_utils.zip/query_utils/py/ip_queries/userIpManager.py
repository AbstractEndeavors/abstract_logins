from datetime import datetime
from typing import List, Dict
from ..query_utils import *
filename = 'userIpQueries'
basename = f'{filename}.json'
USER_IP_QUERIES_DATA = get_yaml_queries_data(filename)
def query_select_user_ip():
    """Generate query to check if a user IP record exists."""
    return USER_IP_QUERIES_DATA.get('query_select_user_ip')
def query_update_user_ip():
    """Generate query to update last_seen and hit_count for a user IP."""
    return USER_IP_QUERIES_DATA.get('query_update_user_ip')
def query_insert_user_ip():
    """Generate query to insert a new user IP record."""
    return USER_IP_QUERIES_DATA.get('query_insert_user_ip')
def query_select_user_by_ip():
    """Generate query to select user details by IP address."""
    return USER_IP_QUERIES_DATA.get('query_select_user_by_ip')
class UserIPManager(metaclass=SingletonMeta):
    """Manages operations on the user_ips table, including logging and querying user IP data."""
    def __init__(
        self,
        logs_on=True
        ):
        if not hasattr(self, 'initialized') or self.initialized == False:
            self.initialized = True
            self.logs_on = logs_on or False
            self.toggle_trigger = {True:False,False:True}
            self._query_select_user_ip = query_select_user_ip()
            self._query_update_user_ip = query_update_user_ip()
            self._query_insert_user_ip = query_insert_user_ip()
            self._query_select_user_by_ip = query_select_user_by_ip()

    def toggle_logs(
        self,
        toggle=True
        ):
        if toggle in [True,False]:
            self.logs_on = toggle
        elif toggle == None:
            self.logs_on = self.toggle_trigger.get(self.logs_on)


    def select_user_ip(
        self,
        user_id: int,
        ip: str
        ):
        """Check if a user IP record exists in the user_ips table."""
        if self.logs_on:
            initialize_call_log()
        query = self._query_select_user_ip
        args = (user_id, ip)
        return select_rows(query, *args)


    def update_user_ip(
        self,
        user_id: int,
        ip: str
        ):
        """Update the last_seen timestamp and increment hit_count for a user IP."""
        if self.logs_on:
            initialize_call_log()
        query = self._query_update_user_ip
        time_now = datetime.utcnow()
        args = (time_now, user_id, ip)
        insert_query(query, *args)


    def insert_user_ip(
        self,
        user_id: int,
        ip: str
        ):
        """Insert a new user IP record into the user_ips table."""
        if self.logs_on:
            initialize_call_log()
        query = self._query_insert_user_ip
        args = (user_id, ip)
        insert_query(query, *args)


    def log_user_ip(
        self,
        user_id: int,
        ip: str
        ):
        """
        Insert or update the user_ips table for the given (user_id, ip) pair.
        If the record exists, update it; otherwise, insert a new record.
        """
        if self.logs_on:
            initialize_call_log()
       
        rows = self.select_user_ip(user_id, ip)
        if rows:
            self.update_user_ip(user_id, ip)
            return rows
        else:
            self.insert_user_ip(user_id, ip)
        return self.select_user_ip(user_id, ip)

    def select_user_by_ip(
        self,
        ip: str
        ):
        """Retrieve user details associated with the given IP address."""
        if self.logs_on:
            initialize_call_log()
        query = self._query_select_user_by_ip
        args = (ip,)
        return select_rows(query, *args)


    def get_user_by_ip(
        self,
        ip: str
        ):
        """
        Return all users who have been seen from the given IP, along with timestamps.
        Initializes call logging before querying.
        """
        if self.logs_on:
            initialize_call_log()
        initialize_call_log()
        return self.select_user_by_ip(ip)
