from datetime import datetime
from typing import List, Dict
from ..query_utils import *

class BaseQueryManager(metaclass=SingletonMeta):
    """
    Generic query manager: you give it a basename (e.g. 'uploadQueries'),
    it loads '<basename>.json' and then exposes self._query_<key> for
    every key in that file.
    """
    def __init__(self, basename: str, logs_on: bool = True):
        # only run once per basename thanks to SingletonMeta
        if getattr(self, "_initialized", False):
            return
        self._initialized = True

        self.logs_on = logs_on
        self.toggle_trigger = {True: False, False: True}

        # load your JSON / YAML for this manager
        data = get_yaml_queries_data(basename)

        # dynamically set self._query_<key> = the SQL string
        for key, sql in data.items():
            setattr(self, f"_query_{key}", sql)

    def toggle_logs(self, toggle: bool = None):
        if toggle is None:
            self.logs_on = self.toggle_trigger[self.logs_on]
        else:
            self.logs_on = bool(toggle)


class UploadManager(BaseQueryManager):
    """Manages CRUD on uploads; all your original methods just wired up dynamically."""
    def __init__(self, logs_on: bool = True):
        self.filename = 'uploadQueries'
        self.basename = f'{self.filename}.json'
     
        super().__init__(self.filename, logs_on=logs_on)

    def select_upload_items(self, uploader_id: str = None) -> List[Dict]:
        if self.logs_on:
            initialize_call_log()
        query = self._query_query_select_upload_items
        args = ()
        if uploader_id:
            query += " WHERE uploader_id = %s"
            args = (uploader_id,)
        try:
            return select_distinct_rows(query, *args)
        except Exception as e:
            print(f"DB error in select_upload_items: {e}")
            return []

    def insert_upload_items(
        self,
        filename: str,
        filepath: str,
        uploader_id: str = None,
        shareable: bool = False,
        download_count: int = 0,
        download_limit: int = None,
        share_password: bool = False,
    ) -> int:
        if self.logs_on:
            initialize_call_log()
        query = self._query_query_insert_upload_items
        args = (
            filename,
            filepath,
            uploader_id,
            shareable,
            download_count,
            download_limit,
            share_password,
        )
        row = select_rows(query, *args)
        if row and "id" in row:
            return row["id"]
        raise ValueError("Failed to create fileId: no ID returned from database")

    def select_upload_from_id(self, file_id: int) -> Dict:
        if self.logs_on:
            initialize_call_log()
        query = self._query_query_select_upload_from_id
        row = select_rows(query, file_id)
        return (row or [{}])[0]

    def update_upload_share_link(
        self,
        shareable: bool,
        pwd_plain: str,
        download_limit: int,
        file_id: int,
    ) -> None:
        if self.logs_on:
            initialize_call_log()
        query = self._query_query_update_upload_share_link
        execute_query(query, shareable, pwd_plain, download_limit, file_id)

    def select_upload_from_filepath(self, filepath: str) -> Dict:
        if self.logs_on:
            initialize_call_log()
        query = self._query_query_select_upload_from_filepath
        row = select_rows(query, filepath)
        return (row or [{}])[0]
