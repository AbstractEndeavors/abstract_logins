from datetime import datetime
from typing import List, Dict
from ..query_utils import *
filename = 'userQueries'
basename = f'{filename}.json'
USER_QUERIES_DATA = get_yaml_queries_data(filename)
def query_select_user_by_username():
    """Generate query to select a user by username."""
    return USER_QUERIES_DATA.get('query_select_user_by_username')
def query_insert_update_user():
    """Generate query to insert or update a user record."""
    return USER_QUERIES_DATA.get('query_insert_update_user')
def query_select_existing_user():
    """Generate query to select an existing user record."""
    return USER_QUERIES_DATA.get('query_select_existing_user')
class UserManager(metaclass=SingletonMeta):
    """Manages operations on the user_ips table, including logging and querying user IP data."""
    def __init__(
        self,
        logs_on=True
        ):
        if not hasattr(self, 'initialized'):
            self.initialized = True
            self.logs_on = logs_on or False
            self.toggle_trigger = {True:False,False:True}
            self._query_select_user_by_username = query_select_user_by_username()
            self._query_insert_update_user = query_insert_update_user()
            self._query_select_existing_user = query_select_existing_user()

    def toggle_logs(
        self,
        toggle=True
        ):
        if toggle in [True,False]:
            self.logs_on = toggle
        elif toggle == None:
            self.logs_on = self.toggle_trigger.get(self.logs_on)

    def get_existing_users(
        self
        ):
        """Check if a user IP record exists in the user_ips table."""
        if self.logs_on:
            initialize_call_log()
        query = self._query_select_existing_user 
        rows = select_rows(query) or []
  
        return get_rows(rows)


    def get_insert_update_user(
        self,username: str,
        plaintext_pwd: str,
        is_admin: bool = None
        ) -> None:
        """Update the last_seen timestamp and increment hit_count for a user IP."""
        if self.logs_on:
            initialize_call_log()
        is_admin = is_admin or False
        hashed = bcrypt_plain_text(plaintext_pwd,rounds=12)
        query = self._query_insert_update_user
        args = (username, hashed, is_admin,)
        insert_query(query,*args)

    def get_select_user_by_username(
        self,
        username: str
        ) -> None:
        """Insert a new user IP record into the user_ips table."""
        if self.logs_on:
            initialize_call_log()
        query = self._query_select_user_by_username
        args = (username,)
        rows = select_rows(query,*args)
        return get_rows(rows)

