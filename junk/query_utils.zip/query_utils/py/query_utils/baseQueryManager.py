from .query_utils import *
from .paths import *
class BaseQueryManager(metaclass=SingletonMeta):
    """
    Generic query manager: you give it a basename (e.g. 'uploadQueries'),
    it loads '<basename>.json' and then exposes self._query_<key> for
    every key in that file.
    """
    def __init__(self, basename: str, logs_on: bool = True):
        # only run once per basename thanks to SingletonMeta
        if getattr(self, "_initialized", False):
            return
        self._initialized = True

        self.logs_on = logs_on
        self.toggle_trigger = {True: False, False: True}

        # load your JSON / YAML for this manager
        data = get_yaml_queries_data(basename)

        # dynamically set self._query_<key> = the SQL string
        for key, sql in data.items():
            setattr(self, f"_query_{key}", sql)

    def toggle_logs(self, toggle: bool = None):
        if toggle is None:
            self.logs_on = self.toggle_trigger[self.logs_on]
        else:
            self.logs_on = bool(toggle)
