from datetime import datetime
from typing import List, Dict
from ..query_utils import *
filename = 'tableQueries'
basename = f'{filename}.json'
TABLE_QUERIES_DATA = get_yaml_queries_data(filename)
def create_users_table():
    """Generate query to check if a uploads table record exists."""
    return TABLE_QUERIES_DATA.get('create_users_table')
def create_update_triggers():
    """Generate query to check if a uploads table record exists."""
    return TABLE_QUERIES_DATA.get('create_update_triggers')
def create_triggers():
    """Generate query to update last_seen and hit_count for a uploads table."""
    return TABLE_QUERIES_DATA.get('create_triggers')

class TableManager(metaclass=SingletonMeta):
    """Manages operations on the user_ips table, including logging and querying user IP data."""
    def __init__(
        self,
        logs_on=True
        ):
        if not hasattr(self, 'initialized') or self.initialized == False:
            self.initialized = True
            self.logs_on = logs_on or False
            self.toggle_trigger = {True:False,False:True}
            self._create_users_table = create_users_table()
            self._create_update_triggers = create_update_triggers()
            self._create_triggers = create_triggers()

    def toggle_logs(
        self,
        toggle=True
        ):
        if toggle in [True,False]:
            self.logs_on = toggle
        elif toggle == None:
            self.logs_on = TableManager.toggle_trigger.get(self.logs_on)

    def create_users_table(
        self
        ):
        """Check if a uploads table record exists in the uploads_tables table."""
        if self.logs_on:
            initialize_call_log()
        query = self._create_users_table
        execute_query(query)
    def create_update_triggers(
        self
        ):
        """Check if a uploads table record exists in the uploads_tables table."""
        if self.logs_on:
            initialize_call_log()
        query = self._create_update_triggers
        execute_query(query)
    def create_triggers(
        self
        ):
        """Check if a uploads table record exists in the uploads_tables table."""
        if self.logs_on:
            initialize_call_log()
        query = self._create_triggers
        execute_query(query)
