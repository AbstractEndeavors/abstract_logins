from .secure_settings import secure_settings_bp
from .get_endpoints import secure_endpoints_bp
